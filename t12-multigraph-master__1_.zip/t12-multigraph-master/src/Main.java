import java.io.IOException;

public class Main {
    public static void main(String[] args) throws NoSuchNodeException, IOException, BadFileException {
        BostonMetro bm = new BostonMetro();

    }
}
