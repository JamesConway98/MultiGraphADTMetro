public class BadFileException extends Exception{
	public BadFileException(String arg){
		super(arg);
	}
}
