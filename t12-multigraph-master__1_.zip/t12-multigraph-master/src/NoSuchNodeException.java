public class NoSuchNodeException extends Exception {
    public NoSuchNodeException() {
        super("No such node found.");
    }
}
